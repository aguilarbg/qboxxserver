Hi, thank you for buying okokGarage! :)

If you need help contact me on discord: okok#3488
Discord server: https://discord.gg/okok
Docs: https://docs.okokscripts.io/

-> Installation Guide: https://docs.okokscripts.io/scripts/okokgarage